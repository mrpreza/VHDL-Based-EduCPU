#!/usr/bin/env python3
"""
Configurable 7-bit assembler for the CODesign project.

This version explicitly opens the input assembly file using UTF-8,
and falls back to cp1252 if UTF-8 fails (Windows common issue).
It produces:
  - <out>.mem.vhdlfrag
  - <out>.bin
  - <out>.list.txt

Usage:
  python assembler.py program.asm --isa isa.default.json --out program
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Tuple

BITS = 7

def parse_int(token: str) -> int:
    t = token.strip().replace('_','')
    if t.startswith(("0b","0B")): return int(t,2)
    if t.startswith(("0x","0X")): return int(t,16)
    return int(t,10)

@dataclass
class Isa:
    reg_enc: Dict[str,str]
    patterns: List[Tuple[re.Pattern,str,str]]  # (regex, template, original key)

    @staticmethod
    def load(path: str) -> "Isa":
        cfg = json.load(open(path,"r",encoding="utf-8"))
        reg_enc = {k.upper():v for k,v in cfg["register_encoding"].items()}
        patterns = []
        for key, templ in cfg["instructions"].items():
            k = re.sub(r"\s+", " ", key.strip().upper())
            opname, *operands = k.split(" ")
            ops = " ".join(operands).strip()
            ops = ops.replace(" ,", ",").replace(", ", ",")
            if ops:
                sym = ops.replace(",", " *, *")
                sym = sym.replace("D","(?P<D>R[0-3])").replace("S","(?P<S>R[0-3])")
                sym = sym.replace("I","(?P<I>[^,\\s]+)").replace("A","(?P<A>[^,\\s]+)")
                pat = re.compile(rf"^{opname}\s+{sym}$", re.IGNORECASE)
            else:
                pat = re.compile(rf"^{opname}$", re.IGNORECASE)
            patterns.append((pat, templ, key))
        return Isa(reg_enc, patterns)

    def encode(self, mnemonic: str, labels: Dict[str,int], curaddr:int) -> int:
        line = re.sub(r"\s+", " ", mnemonic.strip())
        line = line.replace(" ,", ",").replace(", ", ",")
        for pat, templ, key in self.patterns:
            m = pat.match(line)
            if not m: continue
            if len(templ) != BITS:
                raise ValueError(f"Template for '{key}' must be {BITS} chars: '{templ}'")
            bits = []
            get = lambda name: (m.group(name) if name in m.groupdict() else None)
            D = get("D"); S = get("S"); I = get("I"); A = get("A")
            def regbits(rname: str) -> str:
                code = self.reg_enc.get(rname.upper())
                if code is None:
                    raise ValueError(f"Register '{rname}' not in register_encoding")
                if len(code)!=2: raise ValueError("Register encoding must be 2 bits")
                return code
            imm3 = None
            addr = None
            if I is not None:
                imm3 = parse_int(I) & 0b111
            if A is not None:
                aval = A
                if re.fullmatch(r"[A-Za-z_]\w*", aval) and aval.upper() in labels:
                    addr = labels[aval.upper()]
                else:
                    addr = parse_int(aval)
            rd = regbits(D) if D else None
            rs = regbits(S) if S else None
            for ch in templ:
                if ch in "01":
                    bits.append(ch)
                elif ch == 'd':
                    if rd is None: raise ValueError(f"'{key}' expects D operand")
                    bits.append(rd[0]); rd = rd[1:]
                elif ch == 's':
                    if rs is None: raise ValueError(f"'{key}' expects S operand")
                    bits.append(rs[0]); rs = rs[1:]
                elif ch == 'i':
                    if imm3 is None: raise ValueError(f"'{key}' expects I immediate")
                    bits.append(str((imm3 >> 2) & 1)); bits.append(str((imm3 >> 1) & 1)); bits.append(str((imm3 >> 0) & 1))
                    break
                elif ch == 'a':
                    # handled after loop
                    pass
                else:
                    raise ValueError(f"Bad template char '{ch}' in '{templ}'")
            if 'a' in templ:
                acount = templ.count('a')
                if addr is None: raise ValueError(f"'{key}' expects A address")
                if addr >= (1<<acount): addr = addr % (1<<acount)
                abits = [(addr >> (acount-1-i)) & 1 for i in range(acount)]
                bits = []
                adx = 0; rd = regbits(D) if D else None; rs = regbits(S) if S else None
                for ch in templ:
                    if ch in '01': bits.append(ch)
                    elif ch == 'd': bits.append(rd[0]); rd=rd[1:]
                    elif ch == 's': bits.append(rs[0]); rs=rs[1:]
                    elif ch == 'i':
                        bits += [str((imm3 >> 2) & 1), str((imm3 >> 1) & 1), str((imm3 >> 0) & 1)]
                    elif ch == 'a':
                        bits.append(str(abits[adx])); adx+=1
                if len(bits)!=BITS: raise AssertionError("internal template size error")
            bitstr = "".join(bits)
            return int(bitstr, 2)
        raise ValueError(f"Unknown mnemonic / does not match ISA: '{mnemonic}'")

def assemble(isa: Isa, lines: List[str]) -> Tuple[List[int], List[str]]:
    out: List[int] = []
    listing: List[str] = []
    labels: Dict[str,int] = {}
    pc = 0
    for raw in lines:
        line = re.split(r"[;#]", raw, 1)[0].strip()
        if not line: continue
        if line.endswith(":"):
            labels[line[:-1].strip().upper()] = pc; continue
        if line.lower().startswith(".org"):
            pc = int(line.split()[1], 0); continue
        if line.lower().startswith(".fill"):
            _, rest = line.split(None,1); n_s,val_s = [x.strip() for x in rest.split(",")]
            n = int(n_s,0); pc += n; continue
        if line.lower().startswith(".word"):
            pc += 1; continue
        pc += 1
    pc = 0
    for raw in lines:
        src = raw.rstrip("\n")
        line = re.split(r"[;#]", src, 1)[0].strip()
        if not line: continue
        if line.endswith(":"):
            listing.append(f"{pc:03d}: {'':7}    {src}")
            continue
        if line.lower().startswith(".org"):
            pc = int(line.split()[1], 0)
            listing.append(f"{pc:03d}: {'':7}    {src}")
            while len(out) < pc: out.append(0)
            continue
        if line.lower().startswith(".fill"):
            _, rest = line.split(None,1); n_s,val_s = [x.strip() for x in rest.split(",")]
            n = int(n_s,0); val = int(val_s,0) & ((1<<BITS)-1)
            for _ in range(n): out.append(val); listing.append(f"{len(out)-1:03d}: {val:07b}    {src}")
            pc = len(out)
            continue
        if line.lower().startswith(".word"):
            val = int(line.split()[1],0) & ((1<<BITS)-1)
            out.append(val); listing.append(f"{len(out)-1:03d}: {val:07b}    {src}"); pc=len(out); continue
        val = isa.encode(line, labels, pc)
        out.append(val)
        listing.append(f"{len(out)-1:03d}: {val:07b}    {src}")
        pc = len(out)
    return out, listing

def write_outputs(words: List[int], listing: List[str], outprefix: str):
    with open(outprefix + ".mem.vhdlfrag","w",encoding="utf-8") as f:
        for addr, val in enumerate(words):
            f.write(f'tmpMemory({addr}) <= "{val:07b}" ;\n')
    with open(outprefix + ".bin","wb") as f:
        f.write(bytes([v & 0x7F for v in words]))
    with open(outprefix + ".list.txt","w",encoding="utf-8") as f:
        f.write("\n".join(listing))

def read_asm_file(path: Path) -> List[str]:
    # Try utf-8 first, then fall back to cp1252 (Windows)
    try:
        text = path.read_text(encoding="utf-8")
        return text.splitlines()
    except UnicodeDecodeError:
        try:
            text = path.read_text(encoding="cp1252")
            print("Warning: input file not UTF-8, read with cp1252 fallback. "
                  "If characters look wrong, re-save the ASM file as UTF-8.", file=sys.stderr)
            return text.splitlines()
        except Exception as e:
            raise

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("asm")
    ap.add_argument("--isa", default=str(Path(__file__).with_name("isa.default.json")))
    ap.add_argument("--out", default=None)
    ap.add_argument("--org", default=None, help="starting address (alias for leading .org)")
    args = ap.parse_args()

    isa = Isa.load(args.isa)
    asm_path = Path(args.asm)
    if not asm_path.exists():
        print(f"Error: asm file not found: {asm_path}", file=sys.stderr)
        sys.exit(2)
    try:
        src = read_asm_file(asm_path)
    except Exception as e:
        print(f"Failed to read asm file: {e}", file=sys.stderr)
        sys.exit(3)

    if args.org is not None:
        src = [f".org {args.org}"] + src
    words, listing = assemble(isa, src)
    outprefix = args.out or str(Path(args.asm).with_suffix(""))
    write_outputs(words, listing, outprefix)
    print(f"Assembled {len(words)} words -> {outprefix}.mem.vhdlfrag, .bin, .list.txt")

if __name__ == "__main__":
    main()
